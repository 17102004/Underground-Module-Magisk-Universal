#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53

# This script will be executed in late_start service mode
# More info in the main Magisk thread

ifconfig eth0 txqueuelen 100

iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53 2>/dev/null
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.1.1.1:53 2>/dev/null
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.0.0.1:53 2>/dev/null
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53 2>/dev/null

echo 5 > /proc/sys/net/ipv4/tcp_fin_timeout
echo 30 > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo 5 > /proc/sys/net/ipv4/tcp_keepalive_probes
echo 1 > /proc/sys/net/ipv4/tcp_tw_recycle
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse
echo 10000000 > /proc/sys/fs/file-max
echo 250000 > /sys/module/nf_conntrack/parameters/hashsize
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
echo 1 > /proc/sys/net/ipv4/conf/all/rp_filter
echo 1 > /proc/sys/net/ipv4/conf/default/rp_filter
echo 1 > /proc/sys/net/ipv4/tcp_sack
echo 1 > /proc/sys/net/ipv4/tcp_window_scaling
echo 1 > /proc/sys/net/ipv4/tcp_no_metrics_save
echo 8738000 > /proc/sys/net/core/rmem_max
echo 6553600 > /proc/sys/net/core/wmem_max
echo 8192,873800,8738000 > /proc/sys/net/ipv4/tcp_rmem
echo 4096,655360,6553600 > /proc/sys/net/ipv4/tcp_wmem
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse
echo 360000 > /proc/sys/net/ipv4/tcp_max_tw_buckets
echo 30000 > /proc/sys/net/core/netdev_max_backlog
echo 16384  > /proc/sys/net/ipv4/tcp_max_syn_backlog
echo 30000,65535 > /proc/sys/net/ipv4/ip_local_port_range
echo 1 > /proc/sys/net/ipv4/tcp_synack_retries
echo 400000 > /proc/sys/net/ipv4/tcp_max_orphans
echo 1000000 > /proc/sys/net/netfilter/nf_conntrack_max
